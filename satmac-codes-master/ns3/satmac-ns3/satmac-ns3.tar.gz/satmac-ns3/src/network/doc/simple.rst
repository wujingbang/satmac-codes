.. include:: replace.txt

Simple NetDevice
----------------

*Placeholder chapter*
